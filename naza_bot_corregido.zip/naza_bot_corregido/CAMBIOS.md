# 📋 CAMBIOS REALIZADOS - NAZA Bot (Backend)

## Fecha: 24 de Noviembre, 2025

---

## ✅ CORRECCIONES APLICADAS

### 1. **Estructura del Bot Actualizada**
- ✅ Bot ya está correctamente configurado para NO crear suscripciones en Braintree
- ✅ El endpoint `/api/payment/process` solo guarda datos como "pending"
- ✅ El webhook `/api/braintree/webhook` maneja la confirmación de pago
- ✅ El flujo de OAuth2 con Discord funciona correctamente

### 2. **Variables de Entorno Clarificadas**
- ✅ Creado `.env.example` con todas las variables documentadas
- ⚠️ **IMPORTANTE:** Las siguientes variables en tu entorno NO se usan y pueden causar confusión:
  - `CPLAN_ID_ANUALNOW: 796655126` ❌ NO USAR
  - `CPLAN_ID_MENSUALNOW: 1375179357` ❌ NO USAR
  - `CPLAN_ID_TRIMESTRALNOW: 335904819` ❌ NO USAR
  
  **Estos IDs numéricos son de otra pasarela (posiblemente NowPayments) y NO son compatibles con Braintree.**

### 3. **plan_id Correcto**
El bot usa correctamente plan_id tipo **string**:
- ✅ `plan_mensual` → Asigna rol: ROLE_ID_SENALESDISCORD
- ✅ `plan_trimestral` → Asigna rol: ROLE_ID_MENTORIADISCORD
- ✅ `plan_anual` → Asigna rol: ROLE_ID_ANUALDISCORD

### 4. **FRONTEND_TOKEN**
- ✅ El bot espera: `FRONTEND_TOKEN=NAZA_TEST_123`
- ✅ Este valor DEBE coincidir con el configurado en el sitio web
- ⚠️ Si no coincide, el bot rechaza con error 401 Unauthorized

---

## 🔄 FLUJO CORRECTO DE PAGO

```mermaid
graph TD
    A[Cliente llena formulario] --> B[Sitio web captura datos]
    B --> C[Envía al bot como pending]
    C --> D[Bot guarda en BD status=pending]
    D --> E[Drop-in de Braintree procesa pago]
    E --> F[Braintree envía webhook al bot]
    F --> G[Bot actualiza status=active]
    G --> H[Bot envía email con claim]
    H --> I[Cliente hace OAuth2 con Discord]
    I --> J[Bot asigna rol según plan_id]
```

---

## 📦 ARCHIVOS INCLUIDOS

```
naza_bot_corregido/
├── index.js              # Código del bot (sin cambios, ya estaba correcto)
├── package.json          # Dependencias
├── .env.example          # Variables de entorno documentadas
└── CAMBIOS.md           # Este archivo
```

---

## ⚙️ CONFIGURACIÓN RECOMENDADA

### Variables de Entorno a Configurar:

1. **Seguridad:**
   ```env
   FRONTEND_TOKEN=NAZA_TEST_123
   SHARED_SECRET=NazaFx8upexSecretKey_2024_zzu12AA
   JWT_SECRET=@lex13102001$$$!
   ```

2. **Braintree:**
   ```env
   BRAINTREE_ENV=Sandbox
   BRAINTREE_MERCHANT_ID=ngx2nq8rgh6f73z9
   BRAINTREE_PUBLIC_KEY=ft6h5wb4s9922f3n
   BRAINTREE_PRIVATE_KEY=8d5e2ec0bd58036abac9041481dac004
   ```

3. **Discord:**
   ```env
   DISCORD_BOT_TOKEN=<tu_token_aquí>
   DISCORD_CLIENT_ID=1434648012076093562
   DISCORD_CLIENT_SECRET=Dd_8ZmAQpFnYwbbNGkkD7GhaFMMPkDpU
   GUILD_ID=1431442244493377591
   ROLE_ID_SENALESDISCORD=<id_rol_señales>
   ROLE_ID_MENTORIADISCORD=<id_rol_mentoria>
   ROLE_ID_ANUALDISCORD=1432149252016177233
   ```

4. **Supabase:**
   ```env
   SUPABASE_URL=https://vwndjpylfcekjmluookj.supabase.co
   SUPABASE_SERVICE_ROLE=<tu_service_role_key>
   ```

5. **SendGrid:**
   ```env
   SENDGRID_API_KEY=<tu_api_key>
   FROM_EMAIL=NAZA Trading Academy <support@nazatradingacademy.com>
   ```

---

## 🚀 DEPLOYMENT

### En Render.com:

1. **Subir el código del bot**
   ```bash
   git init
   git add .
   git commit -m "NAZA Bot actualizado"
   git push
   ```

2. **Configurar variables de entorno**
   - Ve a Render Dashboard → Tu servicio → Environment
   - Copia todas las variables de `.env.example`
   - Asegúrate de que `FRONTEND_TOKEN=NAZA_TEST_123`

3. **Configurar webhook de Braintree**
   - URL: `https://naza-fx-bot.onrender.com/api/braintree/webhook`
   - Eventos a escuchar:
     - `subscription_charged_successfully`
     - `subscription_canceled`
     - `subscription_expired`

---

## 🔍 VALIDACIONES IMPORTANTES

### ✅ Checklist de Deployment:

- [ ] `FRONTEND_TOKEN` coincide entre bot y sitio web
- [ ] Webhook de Braintree configurado correctamente
- [ ] Roles de Discord existen en el servidor
- [ ] Bot tiene permisos para asignar roles
- [ ] SendGrid API key válida
- [ ] Supabase conectado correctamente
- [ ] Variables `CPLAN_ID_*` ELIMINADAS del entorno

---

## 📞 SOPORTE

Si encuentras problemas:

1. **Revisa los logs del bot:**
   ```bash
   # En Render.com
   Dashboard → Logs
   ```

2. **Verifica la base de datos:**
   - Tabla `memberships` → Debe tener status "pending" o "active"
   - Tabla `webhook_logs` → Debe registrar eventos de Braintree
   - Tabla `claims_issued` → Debe registrar claims enviados

3. **Prueba el flujo paso a paso:**
   - Cliente llena formulario ✓
   - Bot guarda como pending ✓
   - Braintree procesa pago ✓
   - Webhook llega al bot ✓
   - Email enviado ✓
   - OAuth2 funciona ✓
   - Rol asignado ✓

---

## ⚠️ NOTAS IMPORTANTES

1. **NO usar IDs numéricos para planes** - Solo strings: "plan_mensual", "plan_trimestral", "plan_anual"
2. **El bot NO crea suscripciones** - Solo guarda datos como pending
3. **El Drop-in de Braintree** maneja TODO el proceso de pago en el frontend
4. **El webhook confirma** y activa la membresía
5. **FRONTEND_TOKEN debe coincidir** entre bot y sitio web

---

**Versión:** 2.0 (Corregida)
**Fecha:** 24 de Noviembre, 2025
